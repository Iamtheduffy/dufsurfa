/*
@Russell2259 removed this cause it was annoying. we can add it as a setting

9/24/2023 added as a setting by Derpman^^
9/25/2023 removed since it was buggy by derpman

window.onbeforeunload = function(e) {  return "Do you want to exit this page?";};
console.log("leaveConfirmation.js activated.");
*/